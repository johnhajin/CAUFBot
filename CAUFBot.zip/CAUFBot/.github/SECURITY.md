# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| > 1.0   | :white_check_mark: |
| < 1.0   | :white_check_mark: |

## Reporting a Vulnerability

Write an mail to aiko@aitsys.dev or report it via [Security](https://github.com/TediCross/TediCross/security/advisories/new).
